The tool to change the pid is pid_8to9.exe. There is only one option to write the I2C. It will keep all of the old info and just change the PID from 8 to 9. Please use the change the drivers from slaoxgen to qtprog. If you remove the old references in the register and the old inf file you should be able to install with the attached inf file.

